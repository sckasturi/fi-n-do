//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ipcam_sample.rc
//
#define ID_PLAY_AUDIO                   3
#define ID_DISCONNECT                   4
#define ID_PLAY_VIDEO                   5
#define ID_STOP_VIDEO                   6
#define ID_STOP_AUDIO                   7
#define IDD_IPCAM_SAMPLE_DIALOG         102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDB_FOSCAM                      131
#define IDC_IP                          1000
#define IDC_PORT                        1001
#define IDC_USER                        1002
#define IDC_PWD                         1003
#define IDC_CONN_STATUS                 1004
#define IDC_VIDEO_STATUS                1005
#define IDC_AUDIO_STATUS                1006
#define ID_CONNECT                      1007
#define IDC_BMP                         1009
#define IDC_FOSCAM_NAME                 1010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
